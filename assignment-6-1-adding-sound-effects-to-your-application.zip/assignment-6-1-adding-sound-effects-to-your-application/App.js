import React, { useState, useEffect } from 'react';
import { Text, SafeAreaView, Button, StyleSheet, View } from 'react-native';
import { Audio } from 'expo-av';

export default function App() {
  const [sound, setSound] = useState(null);

  async function playSound(soundFile) {
    try {
      if (sound !== null) {
        await sound.unloadAsync();
      }

      const { sound: newSound } = await Audio.Sound.createAsync(soundFile);
      setSound(newSound);
      await newSound.playAsync();
    } catch (error) {
      console.error('Error when trying to play this sound', error);
    }
  }

  useEffect(() => {
    return () => {
      if (sound) {
        sound.unloadAsync();
      }
    };
  }, [sound]);

  return (
    <SafeAreaView style={styles.container}>
      <Text style={styles.title}>Sound Check</Text>

      <View style={styles.buttonContainer}>
        <Button
          title="CHICKEN JOCKEY"
          onPress={() => playSound(require('./assets/chicken-jockey.mp3'))}
        />
      </View>

      <View style={styles.buttonContainer}>
        <Button title="I am STEVE" onPress={() => playSound(require('./assets/i-am-steve.mp3'))} />
      </View>

      <View style={styles.buttonContainer}>
        <Button title="Smoke Detector" onPress={() => playSound(require('./assets/smoke-detector-beep.mp3'))} />
      </View>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    padding: 20,
    backgroundColor: '#fff',
  },
  title: {
    fontSize: 24,
    marginBottom: 30,
    textAlign: 'center',
  },
  buttonContainer: {
    marginBottom: 15,
  },
});
